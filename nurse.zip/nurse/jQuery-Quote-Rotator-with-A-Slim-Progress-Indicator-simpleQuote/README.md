jquery-quote-rotator
====================

Alternative method to Co Drops quote rotator which works in I.E
